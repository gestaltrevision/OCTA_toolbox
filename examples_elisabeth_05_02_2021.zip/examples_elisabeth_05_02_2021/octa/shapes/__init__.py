# -*- coding: utf-8 -*-
"""
Created on Tue May  5 15:58:04 2020

@author: Christophe
"""


from octa.shapes.Rectangle import Rectangle
from octa.shapes.Ellipse import Ellipse
from octa.shapes.Triangle import Triangle
from octa.shapes.Text import Text
from octa.shapes.Image import Image
from octa.shapes.RegularPolygon import RegularPolygon
from octa.shapes.Polygon import Polygon
from octa.shapes.Path import Path
from octa.shapes.PathSvg import PathSvg


from octa.shapes.FitImage import FitImage
from octa.shapes.ChangingEllipse import ChangingEllipse