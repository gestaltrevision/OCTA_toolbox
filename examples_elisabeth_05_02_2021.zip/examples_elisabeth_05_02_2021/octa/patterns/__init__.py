# -*- coding: utf-8 -*-
"""
Created on Tue May  5 15:58:04 2020

@author: Christophe
"""

from octa.patterns.Pattern import Pattern, Sequence, LinearGradient

import octa.patterns.GridPattern
